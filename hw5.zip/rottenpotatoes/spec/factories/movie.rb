FactoryGirl.define do
    factory :movie do
        id '1'
        title 'Blazing Saddles'
        rating 'R'
        release_date '7/2/1974'
    end
end
